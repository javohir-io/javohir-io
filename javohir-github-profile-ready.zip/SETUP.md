# Setup

1. Copy the contents of this folder into the root of your GitHub profile repository.
2. Rename `YOUR_USERNAME` in `README.md` to your GitHub username.
3. Commit and push.
4. GitHub will render the local SVG assets from `assets/` and select the dark/light versions via `<picture>`.

The `assets/dark/` directory is included so the README works immediately with the same structure as the reference design.
